export interface User {
  name: string;
  given_name: string;
  family_name: string;
  website: string;
  sub: string;
}
